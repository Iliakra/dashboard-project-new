(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.txt3_offer_cd = function() {
  this.initialize(img.txt3_offer_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 122, null);
 (lib.txt3_price_cd = function() {
  this.initialize(img.txt3_price_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 120, null);
 (lib.txt3_priceOpts_cd = function() {
  this.initialize(img.txt3_priceOpts_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 145, null);
 (lib.txt3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_offer = new lib.txt3_offer_cd();
  this.cvr_offer.name = "cvr_offer";
  this.cvr_offer.parent = this;
  this.cvr_offer.setTransform(461, 13, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_offer).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_offer).wait(1));
  this.cvr_price = new lib.txt3_price_cd();
  this.cvr_price.name = "cvr_price";
  this.cvr_price.parent = this;
  this.cvr_price.setTransform(455, 21, 1.0083, 1.0002);
  this.timeline.addTween(cjs.Tween.get(this.cvr_price).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_price).wait(1));
  this.cvr_priceOpts = new lib.txt3_priceOpts_cd();
  this.cvr_priceOpts.name = "cvr_priceOpts";
  this.cvr_priceOpts.parent = this;
  this.cvr_priceOpts.setTransform(444, 25, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_priceOpts).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_priceOpts).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(442, 11, 149.5, 43.2), null);
 (lib.txt_t_1_t_1_cd = function() {
  this.initialize(img.txt_t_1_t_1_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 235, null);
 (lib.txt_t_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_1 = new lib.txt_t_1_t_1_cd();
  this.cvr_t_1.name = "cvr_t_1";
  this.cvr_t_1.parent = this;
  this.cvr_t_1.setTransform(11, 6, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_t_1, new cjs.Rectangle(9, 4, 239, 57.2), null);
 (lib.txt_b_5_b_5_cd = function() {
  this.initialize(img.txt_b_5_b_5_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 211, null);
 (lib.txt_b_5 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.isSingleFrame = false;
  this.frame_0 = function() {
   if (this.isSingleFrame) {
    return;
   }
   if (this.totalFrames == 1) {
    this.isSingleFrame = true;
   }
   var textHeight = {
    alxSize: "b_5",
    height: 60
   }.height;
   this.alx_txt_b_5.y = -15 - textHeight;
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
  this.cvr_b_5 = new lib.txt_b_5_b_5_cd();
  this.cvr_b_5.name = "cvr_b_5";
  this.cvr_b_5.parent = this;
  this.cvr_b_5.setTransform(410, -68, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_5).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_5).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_b_5, new cjs.Rectangle(408, -70, 215, 60), null);
 (lib.txt_b_4_b_4_cd = function() {
  this.initialize(img.txt_b_4_b_4_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 211, null);
 (lib.txt_b_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.isSingleFrame = false;
  this.frame_0 = function() {
   if (this.isSingleFrame) {
    return;
   }
   if (this.totalFrames == 1) {
    this.isSingleFrame = true;
   }
   var textHeight = {
    alxSize: "b_4",
    height: 60
   }.height;
   this.alx_txt_b_4.y = -15 - textHeight;
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
  this.cvr_b_4 = new lib.txt_b_4_b_4_cd();
  this.cvr_b_4.name = "cvr_b_4";
  this.cvr_b_4.parent = this;
  this.cvr_b_4.setTransform(410, -68, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_4).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_4).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_b_4, new cjs.Rectangle(408, -70, 215, 60), null);
 (lib.txt_b_3_b_3_cd = function() {
  this.initialize(img.txt_b_3_b_3_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 211, null);
 (lib.txt_b_3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.isSingleFrame = false;
  this.frame_0 = function() {
   if (this.isSingleFrame) {
    return;
   }
   if (this.totalFrames == 1) {
    this.isSingleFrame = true;
   }
   var textHeight = {
    alxSize: "b_3",
    height: 60
   }.height;
   this.alx_txt_b_3.y = -15 - textHeight;
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
  this.cvr_b_3 = new lib.txt_b_3_b_3_cd();
  this.cvr_b_3.name = "cvr_b_3";
  this.cvr_b_3.parent = this;
  this.cvr_b_3.setTransform(410, -68, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_b_3, new cjs.Rectangle(408, -70, 215, 60), null);
 (lib.txt_b_2_b_2_cd = function() {
  this.initialize(img.txt_b_2_b_2_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 211, null);
 (lib.txt_b_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.isSingleFrame = false;
  this.frame_0 = function() {
   if (this.isSingleFrame) {
    return;
   }
   if (this.totalFrames == 1) {
    this.isSingleFrame = true;
   }
   var textHeight = {
    alxSize: "b_2",
    height: 60
   }.height;
   this.alx_txt_b_2.y = -15 - textHeight;
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
  this.cvr_b_2 = new lib.txt_b_2_b_2_cd();
  this.cvr_b_2.name = "cvr_b_2";
  this.cvr_b_2.parent = this;
  this.cvr_b_2.setTransform(410, -68, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_b_2, new cjs.Rectangle(408, -70, 215, 60), null);
 (lib.txt_b_1_b_1 = function() {
  this.initialize(img.txt_b_1_b_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 211, null);
 (lib.txt_b_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.isSingleFrame = false;
  this.frame_0 = function() {
   if (this.isSingleFrame) {
    return;
   }
   if (this.totalFrames == 1) {
    this.isSingleFrame = true;
   }
   var textHeight = {
    alxSize: "b_1",
    height: 60
   }.height;
   this.alx_txt_b_1.y = -15 - textHeight;
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
  this.cvr_b_1 = new lib.txt_b_1_b_1();
  this.cvr_b_1.name = "cvr_b_1";
  this.cvr_b_1.parent = this;
  this.cvr_b_1.setTransform(410, -68, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.txt_b_1, new cjs.Rectangle(408, -70, 215, 60), null);
 (lib.s_edition = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AGQBDQgDAAgCgCIgFgEIgfguIgCgCQgBAAAAABQgBAAAAAAQgBAAAAAAQAAABgBAAIgjAuQgFAGgFAAIgZAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAgDABgCIA8hNQAEgFAGAAIAQAAIAGACQADABACACIAfAtQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAABgBIAkgtQAEgFAGAAIAZAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQABADgCABIg8BNIgEAEQgDACgDAAgAB7BDQgDAAgBgDQgBAAAAgBQAAgBABAAQAAgBAAAAQABgBABAAIA+hNIABAAQAEgEAFgBIBxAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAABABQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIg7BNQgEAGgHAAgADPACIghApIgBACIACAAIAqAAQAEAAAEgFIAegnIABgBQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIglAAQgGAAgDADgAA1BDQAAAAgBAAQgBAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAIA7hNIAFgDIAGgCIAbAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAIg7BNQgFAGgGAAgAgPBDQAAAAgBAAQgBAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAIAug8IgfAAQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBgDACgDIAGgJIAFgDQADgCADAAIAiAAIAdgnIAEgDIAGgCIAbAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABACgCADIhdB4IgFAEIgFACgAh6BDQgBAAgBAAQAAAAAAgBQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAIA7hNQAEgEAGgBIAcAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAIg7BNIgFAEQgDACgDAAgAkZBDQgDAAgBgDQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAIA+hNQABgCAEgBIAFgCIBNAAQAFAAADgEIAZgjIAGgDIAFgCIAaAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQACACgDADIhdB4QgEAGgHAAgAjBAAIgEACIghApIgBACIACAAIAqAAIAEgBIAEgEIAegnQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAAAAAAAIgmAAIgEABgAm5BDQgEAAgBgDQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAIA7hNIAFgDIAGgCIB2AAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAIgHAKQgCADgDABQgDACgDAAIhPAAQgFAAgDADIgEAGQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAAAIABABIBRAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAAAQABADgCAEIgBAAIgHAIQgEAFgGAAIhQAAQgFAAgDAFIgDAFQgBAAAAAAQAAABAAAAQAAABAAAAQAAAAAAABIABAAIBQAAQABAAAAAAQABAAABAAQAAAAAAABQABAAAAAAQABADgCADIgGAJQgCACgDACQgDACgDAAgAniAgQgBAAgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQgBgCACgCIAIgKQAEgFAFAAIAkAAQABAAAAAAQABAAABABQAAAAAAAAQABABAAAAQABACgCAEIgIAIQAAADgEABIgGABg");
  this.shape.setTransform(76.385, 6.7);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#DC2A1B").s().p("AlhBVQAAAAgBgBQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBIAHgJQABgDAEgBIAFgBIOaAAQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAABAAAAIgHAJQgBACgEACQgBAAAAABQgBAAAAAAQgBAAAAAAQgBABgBAAgApEBVQgEgBgCgCQgBgDADgFIALgQQAEgEAFgDQAGgCAEAAIB8AAQAKAAADgGIANgRQADgEgCgCIg8guIgCgDIAAgCIAAgBIACgDIAfgpIAFgFQAEgCAEgBICjAAQABAAAAABQABAAAAAAQABAAAAABQABAAAAABQABACgDAEIgPAVIgGAFIgHABIhoAAQgDABgEACQgEACgBADIgFAFQgCADACADIBCAzQABAAAAAAQAAABABAAQAAABAAABQAAAAAAABQABAEgCADIggAqQgDAEgGADQgFADgFAAg");
  this.shape_1.setTransform(58.7188, 8.55);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.s_edition, new cjs.Rectangle(0, 0, 125.1, 17), null);
 (lib.red_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#D20913", "rgba(234,19,42,0.902)", "rgba(210,9,19,0.8)"], [0, 0.392, 1], -69.6, 0, 69.6, 0).s().p("AqvgHIIwAAIMYAHIAfADI1vAFg");
  this.shape.setTransform(69.625, 42.1);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.lf(["#D20913", "rgba(234,19,42,0.902)", "rgba(210,9,19,0.8)"], [0, 0.392, 1], -35.6, 0, 35.5, 0).s().p("AljAAILGgGIgFANg");
  this.shape_1.setTransform(120.6, 1.2);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.lf(["#EA132A", "rgba(234,19,42,0.498)"], [0.008, 1], -40.8, -32.4, 63.7, -0.7).s().p("AjVDKIowAAIA4h0IA2gZIBvj8IGKAAIlrgRIJNAAILCAHIgpCJIgtA0Ig/DJIjJABICbATg");
  this.shape_2.setTransform(78.225, 21.575);
  this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.red_plate, new cjs.Rectangle(0, 0.5, 156.2, 42.4), null);
 (lib.logo_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["rgba(255,255,255,0.902)", "rgba(255,255,255,0)"], [0.412, 1], -11.5, -11.7, 0, -11.5, -11.7, 116.5).s().p("ApvJwQkDkCAAluQAAltEDkCQECkDFtAAQFuAAECEDQECECAAFtQAAFukCECQkCECluAAQltAAkCkCg");
  this.shape.setTransform(88.25, 88.25);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.logo_2, new cjs.Rectangle(0, 0, 176.5, 176.5), null);
 (lib.logo_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["#FFFFFF", "#DEDFE0", "#C0C2C3", "#A3A5A7", "#565656"], [0.231, 0.396, 0.604, 0.859, 1], -0.3, -0.9, 0, -0.3, -0.9, 89.3).s().p("ApvJwQkDkCAAluQAAltEDkCQECkDFtAAQFuAAECEDQECECAAFtQAAFukCECQkCECluAAQltAAkCkCg");
  this.shape.setTransform(88.25, 88.25);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0, 0, 176.5, 176.5), null);
 (lib.lgl_main_legal1_cd = function() {
  this.initialize(img.lgl_main_legal1_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 606, null);
 (lib.lgl_main = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_legal1 = new lib.lgl_main_legal1_cd();
  this.cvr_legal1.name = "cvr_legal1";
  this.cvr_legal1.parent = this;
  this.cvr_legal1.setTransform(2, 2, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_legal1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_legal1).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.lgl_main, new cjs.Rectangle(0, 0, 610, 69), null);
 (lib.img_bg5_bg5_cd = function() {
  this.initialize(img.img_bg5_bg5_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 750, 135);
 (lib.img_bg5 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this._renderFirstFrame();
  this.cvr_bg5 = new lib.img_bg5_bg5_cd();
  this.cvr_bg5.name = "cvr_bg5";
  this.cvr_bg5.parent = this;
  this.cvr_bg5.setTransform(0, 0, 0.6666666666666666, 0.6666666666666666);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg5).wait(1));
 }).prototype = getMCSymbolPrototype(lib.img_bg5, new cjs.Rectangle(0, 0, 500, 90), null);
 (lib.img_bg4_bg4_cd = function() {
  this.initialize(img.img_bg4_bg4_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 750, 135);
 (lib.img_bg4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this._renderFirstFrame();
  this.cvr_bg4 = new lib.img_bg4_bg4_cd();
  this.cvr_bg4.name = "cvr_bg4";
  this.cvr_bg4.parent = this;
  this.cvr_bg4.setTransform(0, 0, 0.6666666666666666, 0.6666666666666666);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg4).wait(1));
 }).prototype = getMCSymbolPrototype(lib.img_bg4, new cjs.Rectangle(0, 0, 500, 90), null);
 (lib.img_bg3_bg3_cd = function() {
  this.initialize(img.img_bg3_bg3_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 750, 135);
 (lib.img_bg3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this._renderFirstFrame();
  this.cvr_bg3 = new lib.img_bg3_bg3_cd();
  this.cvr_bg3.name = "cvr_bg3";
  this.cvr_bg3.parent = this;
  this.cvr_bg3.setTransform(0, 0, 0.6666666666666666, 0.6666666666666666);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.img_bg3, new cjs.Rectangle(0, 0, 500, 90), null);
 (lib.img_bg2_bg2_cd = function() {
  this.initialize(img.img_bg2_bg2_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 750, 135);
 (lib.img_bg2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this._renderFirstFrame();
  this.cvr_bg2 = new lib.img_bg2_bg2_cd();
  this.cvr_bg2.name = "cvr_bg2";
  this.cvr_bg2.parent = this;
  this.cvr_bg2.setTransform(0, 0, 0.6666666666666666, 0.6666666666666666);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.img_bg2, new cjs.Rectangle(0, 0, 500, 90), null);
 (lib.img_bg1_bg1_cd = function() {
  this.initialize(img.img_bg1_bg1_cd);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 750, 135);
 (lib.img_bg1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this._renderFirstFrame();
  this.cvr_bg1 = new lib.img_bg1_bg1_cd();
  this.cvr_bg1.name = "cvr_bg1";
  this.cvr_bg1.parent = this;
  this.cvr_bg1.setTransform(0, 0, 0.6666666666666666, 0.6666666666666666);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.img_bg1, new cjs.Rectangle(0, 0, 500, 90), null);
 (lib.extra_button_1_alx_txt_button = function() {
  this.initialize(img.extra_button_1_alx_txt_button);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 143, null);
 (lib.extra_button_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FFFFFF").ss(1, 1, 1).p("ALXhyIj8AAIh1AAIvdAAIhfDlIRaAAIB1AAIB+AAg");
  this.shape.setTransform(72.7, 11.5);
  this.timeline.addTween(cjs.Tween.get(this.shape).to({
   _off: true
  }, 3).wait(1));
  this.alx_txt_button = new lib.extra_button_1_alx_txt_button();
  this.alx_txt_button.name = "alx_txt_button";
  this.alx_txt_button.parent = this;
  this.alx_txt_button.setTransform(73.25, 6, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.alx_txt_button).wait(1));
  this.alx_txt_button.x -= 72;
  this.timeline.addTween(cjs.Tween.get(this.alx_txt_button).to({
   _off: true
  }, 3).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("rgba(0,0,0,0.502)").s().p("AH5BzIh1AAIxaAAIBfjlIPcAAIB2AAID8AAIhgDlg");
  this.shape_1.setTransform(72.7, 11.5);
  this.shape_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({
   _off: false
  }, 0).to({
   _off: true
  }, 2).wait(1));
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#000000").s().p("AH5BzIh1AAIxaAAIBfjlIPcAAIB2AAID8AAIhgDlg");
  this.shape_2.setTransform(72.7, 11.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(4));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-1, -1, 147.5, 25.9);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
  this.shape.setTransform(364, 45);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 728, 90), null);
 (lib.txt_t_1_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2zB+IAAj7MAtnAAAIAAD7g");
  mask.setTransform(145.99, 12.6247);
  this.instance = new lib.txt_t_1();
  this.instance.setTransform(-40, 0);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: -7,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(26));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2zD+IAAj8MAtnAAAIAAD8g");
  mask_1.setTransform(145.99, 25.3997);
  this.instance_1 = new lib.txt_t_1();
  this.instance_1.setTransform(-40, 0);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 0,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 4, 248, 46.8);
 (lib.txt_b_5_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.txt_b_5();
  this.instance.setTransform(-20, 0);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 0,
   alpha: 1
  }, 19, cjs.Ease.get(1)).wait(31));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(388, -70, 235, 60);
 (lib.txt_b_4_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.txt_b_4();
  this.instance.setTransform(-20, 0);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 0,
   alpha: 1
  }, 19, cjs.Ease.get(1)).wait(31));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(388, -70, 235, 60);
 (lib.txt_b_3_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.txt_b_3();
  this.instance.setTransform(-20, 0);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 0,
   alpha: 1
  }, 19, cjs.Ease.get(1)).wait(31));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(388, -70, 235, 60);
 (lib.txt_b_2_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.txt_b_2();
  this.instance.setTransform(-20, 0);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 0,
   alpha: 1
  }, 19, cjs.Ease.get(1)).wait(31));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(388, -70, 235, 60);
 (lib.txt_b_1_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.txt_b_1();
  this.instance.setTransform(-20, 0);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 0,
   alpha: 1
  }, 19, cjs.Ease.get(1)).wait(31));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(388, -70, 235, 60);
 (lib.offer_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_9 = new cjs.Graphics().p("AXxB5IA5iHIWAAAIg5CHg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(9).to({
   graphics: mask_graphics_9,
   x: 298.6153,
   y: 12.1228
  }).wait(35));
  this.instance = new lib.txt3();
  this.instance.setTransform(45.6, 9.2, 1, 1, 0, 0, 0, 65.1, 9.2);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({
   _off: false
  }, 0).to({
   x: 65.1,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(20));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_9 = new cjs.Graphics().p("AWYEIIB5kcIV5AAIh5Ecg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(9).to({
   graphics: mask_1_graphics_9,
   x: 295.3613,
   y: 26.4467
  }).wait(35));
  this.instance_1 = new lib.txt3();
  this.instance_1.setTransform(45.6, 9.2, 1, 1, 0, 0, 0, 65.1, 9.2);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({
   _off: false
  }, 0).to({
   x: 65.1,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(15));
  this.instance_2 = new lib.red_plate();
  this.instance_2.setTransform(534, 40.8, 1, 1, 0, 0, 0, 100, 33.8);
  this.instance_2.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   alpha: 1
  }, 14).wait(30));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(434, 7.5, 157.5, 45.4);
 (lib.log = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("Aq7E3QiHhchJh5QhLh8AAiNQAAhZAlhWQAdhHA8hRQgvBEgbBJQgiBcAABeQAACJBJB4QBHB2CCBaQEVC9GdAAQGeAAEVi9QCChaBHh2QBJh4AAiJQAAhegihcQgdhPg0hIQBBBXAgBLQAkBWAABZQAACNhLB8QhJB5iHBcQkaDCmiAAQmhAAkajCg");
  this.shape.setTransform(110.625, 92.8625);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AKtCTQAqgoABgsQAAhxj/hRQjjhJj2AAQj1AAjjBJQj/BRAABxQABAsAqAoQAtAsBbAgQhhgbg0gtQgwgpAAgvQAAhEBag9QBFgvBugkQBqgiCAgUQCAgTByAAQByAACBATQCAAUBqAiQBuAkBGAvQBYA9ABBEQAAAvgwApQg0AthhAbQBaggAugsg");
  this.shape_1.setTransform(110.65, 30.625);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAACjQg2gBgqheQgohZgOiNQATCGApBWQAqBXAwAAQAwAAArhXQAqhWASiGQgOCNgoBZQgqBeg2ABg");
  this.shape_2.setTransform(110.65, 103.925);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("ABXgvQgnhJgwAAQguAAgoBJQgmBFgUB1QANh8AohMQAohMAzgBQA0ABAoBMQApBMAMB8QgUh1gmhFg");
  this.shape_3.setTransform(110.65, 39.075);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.lf(["#454545", "#454545", "#B2B2B2", "#737373", "#4C4C4C", "#191919"], [0.004, 0.122, 0.349, 0.498, 0.8, 1], 31.1, 61.4, -52.4, -35.8).s().p("AjPE9QiDhahHh2QhJh4AAiIQABhfAhhbQAhhbBAhRQgRBIAGAlQhAB4AAB/QAAB7BFBxQBDBvB7BVQDcCaE0AZQAtAQASAFQAcAHAeAAIAAAAIAAAQQmeAAkTi9g");
  this.shape_4.setTransform(62.4, 90.95);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.lf(["#B2B2B2", "#404040", "#313131", "#2B2B2B"], [0, 0.6, 0.816, 1], -0.3, -36.4, -0.3, 35.3).s().p("AhME2QA8gtAvh6QBHi2AEj9IAAgdIAAgNIAAAAIAjAlIAAABQgCDFgvCjQgtChhIBRIgCABQgsAQgTAFQgVAFgXACIgGAAQAigCAegXg");
  this.shape_5.setTransform(125.575, 106.425);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.lf(["#0D0D0D", "#4C4C4C", "#0D0D0D"], [0, 0.498, 1], -84.6, -16.7, 84.4, -16.7).s().p("Ah/AUIgggqQBMAEBTABQBTgBBNgEIghAqQg9ADhCAAQhBAAg+gDg");
  this.shape_6.setTransform(110.675, 76.1);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.lf(["#232323", "#4C4C4C", "#0D0D0D"], [0, 0.498, 1], -29.5, 0.9, 139.5, 0.9).s().p("AgiBwQjJhKg6htQgGgmAQhIIgCAZQAAA0AyA1QA2A4BkAtQCaBGDfAYIgjAlIAAABQimgWiBgwg");
  this.shape_7.setTransform(55.5297, 58.525);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.lf(["#8C8C8C", "#C4C4C4", "#E5E5E5", "#C4C4C4", "#8C8C8C"], [0, 0.349, 0.498, 0.651, 1], -16, 0, 16, 0).s().p("AAADfQg8AAgwiEQgsh1gGibIgBgpIAAgBIAAABIAgArQAHCSAkBkQAlBkAvABQAwgBAlhkQAkhjAGiTIAhgrIgBAmIAAADQgICmguB2QguB3g6ABg");
  this.shape_8.setTransform(110.65, 96.1);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.lf(["#B2B2B2", "#404040", "#313131", "#2B2B2B"], [0, 0.6, 0.816, 1], 0, -36.4, 0, 35.3).s().p("ABXFIQgSgFgtgQIgBgBQhJhRgtihQguijgDjFIAAgBIAjglIAAAAIAAANIAAAdQAED1BDCzQAwCEA/AuQAdAUAeAEIANABQgeAAgcgHg");
  this.shape_9.setTransform(96.1, 106.425);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.lf(["#5E5E5E", "#A8A8A8", "#6B6B6B", "#A6A6A6", "#CCCCCC", "#CCCCCC", "#B5B5B5", "#797979", "#333333", "#0D0D0D"], [0, 0.059, 0.18, 0.349, 0.451, 0.498, 0.518, 0.557, 0.6, 1], 0, 2, 0, -47.4).s().p("AiYAQIAjgjQA5ADA8AAQA9AAA5gCIAjAiQhIAEhRAAQhQAAhIgEg");
  this.shape_10.setTransform(110.65, 57.975);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.lf(["#666666", "#CCCCCC", "#666666"], [0.251, 0.506, 0.749], -15.4, 0, 15.4, 0).s().p("AB2CAIAAgBQgPhqggg+QgghBgnAAQgmAAggBBQggA+gPBqIgjAkIgBAAIAFglQAQh2AkhNQArhdA1AAQA2AAArBdQAlBNAQB2IAEAlg");
  this.shape_11.setTransform(110.625, 43.3);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.lf(["#A6A6A6", "#383838", "#383838"], [0, 0.6, 1], 0, -25.3, 0, 58.4).s().p("ADzDFQgXivg+h6Qgfg/gkghIgMgLQgggYgjgCIAEAAQAYABAUAEQAYAGAoASIAAAAIABAAQA3A5AoBlQApBnARCIIgfAqIgEgmgAkVDBQASiIAqhnQAohlA5g5IABgBQAfgQAegHQAXgFAfgBQgmACggAZIgLAIQgkAhgiBCQg/B7gXCuIgFAmg");
  this.shape_12.setTransform(110.65, 35.425);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.lf(["#454545", "#454545", "#B2B2B2", "#737373", "#4C4C4C", "#191919"], [0.004, 0.122, 0.349, 0.498, 0.8, 1], -31.1, 61.4, 52.4, -35.8).s().p("AnhHqIAIAAIAGgBQAXgBAVgFQATgFAsgQQE0gZDciaQB7hVBDhvQBFhxAAh7QAAh+hAh4IAAgBQAGgrgRhCQBABRAhBbQAhBbAABfQAACIhIB4QhHB2iDBaQkTC9meAAg");
  this.shape_13.setTransform(158.875, 90.95);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.lf(["#0D0D0D", "#4C4C4C", "#232323"], [0, 0.498, 1], -139.7, 0.9, 29.3, 0.9).s().p("AkEC1IgjglQDfgYCahGQBkgtA1g4QAyg1AAg0QAAgNgCgMQARBCgGAsIAAAAQg7BtjIBKQiBAwimAWg");
  this.shape_14.setTransform(165.7688, 58.525);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#5E5E5E", "#A8A8A8", "#6B6B6B", "#A6A6A6", "#CCCCCC", "#CCCCCC", "#B5B5B5", "#797979", "#333333", "#464645"], [0, 0.059, 0.18, 0.349, 0.451, 0.498, 0.518, 0.557, 0.6, 1], 0, 25.4, 0, -24).s().p("AD3D0IAfgqQA5gGAzgKQCWgdBLgxQAagRANgVQANgUAAgVQAAglgzgoQg0gphZghQicg7i/gOIAAAAQgogSgYgGQgUgEgYgBIgEAAIgPgBIgBAAQgfABgXAFQgeAHgfAQQjBAOieA8QhaAhgzApQgzAoAAAlQAAAsAyAhQBJAyCXAdQA0AKA7AHIAfAqIAAAAQjAgRh9gwQikg/AAhcQAAhxD/hRQDjhJD1AAQD2AADjBJQD/BRAABxQAABcikA/Qh9AwjAARg");
  this.shape_15.setTransform(110.65, 34.525);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }]
  }).wait(1));
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AmnK9QjIg3iXhlQiYhmhTiIQhWiNgBihQABihBRiMQBQiJCUhlQE0jUHhAAQHiAAE1DUQCUBlBQCJQBRCMAAChQAAChhXCNQhSCIiZBmQiXBljHA3QjKA3jiAAQjgAAjKg3gAufi0QghBbgBBeQAACIBJB5QBHB2CDBaQEUC9GdAAQGeAAEVi9QCChaBIh2QBIh5AAiIQAAheghhbQgihbg/hRQACAMAAANQAABciOBTQiiBfkVAfIAAANQAAEPhLDAQhLDBhqAAQhoAAhMjBQhKjAAAkPIAAgNQkVgfijhfQiNhTgBhcIADgZQhABRghBbgAhpEoQAwCEA8AAQA+AAAwiEQAxiGABi0QhHAFhZAAQhXAAhIgFQACC0AxCGgAhcmJQgrBagPCPQBDAEBWAAQBYAABDgEQgQiPgqhaQgrhcg2gBQg1ABgqBcgABcpZQAkAgAhBCQBECJAWDHQDygWCAhCQBug5AAhKQAAhyj/hSQjihIj3gBQj0ABjjBIQj/BSAAByQAABKBuA5QCABDDyAVQAMhjAYhZQAXhTAghAQAihDAlggQAogjAuAAQAwAAAnAjg");
  mask.setTransform(110.3, 75.65);
  this.instance = new lib.logo_2();
  this.instance.setTransform(0.65, 1, 1.2462, 0.8515);
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.logo_1();
  this.instance_1.setTransform(0.65, 1, 1.2462, 0.8515);
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#515151").s().p("AmlLBQjEg4idhpQifhqhYiMQhaiPAAicQAAieBWiLQBTiGCbhqQCahqDGg5QDQg+DjAAQDkAADQA+QDGA5CaBqQCbBqBTCGQBWCLAACeQAACchaCPQhXCMigBqQidBpjDA4QjKA7jdAAQjbAAjKg7gAEsAVIAAABQgECvgmCUQgmCUhABYQgDAGABADQACADAIgBIABAAQCXgSCFgzQCFgzBkhPQBphSA4hnQA4hmAAhtQAAhugxhoQgFgLgIALIgBABQg7BRiKA8QiKA7i+AbIgBAAQgJABgBAJgAtRjZQgxBrAABrQAABtA4BmQA5BnBoBSQBkBPCGAzQCFAzCXASQAIABACgDQABgDgDgGQg/hYgmiUQgniUgEivIAAgBQAAgJgKgBIgBAAQi+gbiKg7QiJg8g8hRIgBgBQgEgGgDAAQgDAAgDAGgAhzAlQAICFAiBcQAiBdAnAAQApAAAhhdQAihcAIiFQABgIgJgBQg7ADgxAAQgwAAg6gDIgBAAQgIABAAAIgAg7lyQgcA3gQBdQgBAKAIAAQAwABAwAAQAyAAAvgBIAAAAQAJAAgCgKQgQhcgcg4Qgcg4ggAAQgfAAgcA4gACepVQgCAEAFAHIACACIAAABQBaB5AhDkQACAHAJgBQDWgcBeg+QAXgOAMgTQANgSAAgTQAAg9iJg+QiRhCjLgWIgDAAQgFAAgCACgAikpXQjMAWiRBCQiLA9AAA+QAAAlAtAfQAuAgBQAXQBRAYBpANQAJABACgIIAAgBQARhuAghbQAhhZAtg8IAAAAQAGgHgDgEQgCgCgFAAIgDAAg");
  this.shape_16.setTransform(110.625, 76.35);
  this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.log, new cjs.Rectangle(-0.6, 0, 222.5, 152.7), null);
 (lib.img_bg5_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_bg5 = new lib.img_bg5();
  this.cvr_bg5.name = "cvr_bg5";
  this.cvr_bg5.setTransform(-250, -45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg5).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.img_bg5_c, new cjs.Rectangle(-250, -45, 500, 90), null);
 (lib.img_bg4_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_bg4 = new lib.img_bg4();
  this.cvr_bg4.name = "cvr_bg4";
  this.cvr_bg4.setTransform(-250, -45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg4).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.img_bg4_c, new cjs.Rectangle(-250, -45, 500, 90), null);
 (lib.img_bg3_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_bg3 = new lib.img_bg3();
  this.cvr_bg3.name = "cvr_bg3";
  this.cvr_bg3.setTransform(-250, -45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg3).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.img_bg3_c, new cjs.Rectangle(-250, -45, 500, 90), null);
 (lib.img_bg2_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_bg2 = new lib.img_bg2();
  this.cvr_bg2.name = "cvr_bg2";
  this.cvr_bg2.setTransform(-250, -45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg2).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.img_bg2_c, new cjs.Rectangle(-250, -45, 500, 90), null);
 (lib.img_bg1_c = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_bg1 = new lib.img_bg1();
  this.cvr_bg1.name = "cvr_bg1";
  this.cvr_bg1.setTransform(-250, -45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_bg1).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.img_bg1_c, new cjs.Rectangle(-250, -45, 500, 90), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.log();
  this.instance.setTransform(38.55, 29.1, 0.2383, 0.2381, 0, 0, 0, 110.8, 76);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#DB0720").s().p("AAIAlQgPgPAAgWQAAgUAPgQQAPgQAWAAQAWAAAOAQQAQAQAAAUQAAAWgQAPQgOAQgWAAQgWAAgPgQgAAYgXQgJAKABANQgBANAJALQAIAIANACQALgCAJgIQAJgLAAgNQAAgNgJgKQgIgIgMgBQgNABgIAIgAi8AlQgQgPAAgWQAAgUAQgQQAQgQAVAAQAWAAAPAQQAQAQAAAUQAAAWgQAPQgPAQgWAAQgVAAgQgQgAisgXQgIAKAAANQAAANAIALQAJAIAMACQALgCAJgIQAJgLAAgNQAAgNgJgKQgIgIgMgBQgMABgJAIgAESAwIgJgVIgnAAIgJAVIgaAAIAphhIAcAAIAoBhgADoAJIAcAAIgOgigAg/AwIAAglIgog8IAbAAIAXApIAagpIAYAAIgnA8IAAAlgACJAtIAAhOIgeAAIAAgSIBSAAIAAASIgeAAIAABOgAkNAtIAAhOIgeAAIAAgSIBTAAIAAASIgfAAIAABOg");
  this.shape.setTransform(38.65, 56.2);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("Al7FeIAAq7IL3AAIAAK7g");
  this.shape_1.setTransform(39, 35);
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#999999").s().p("AmFFjIAArFIMLAAIAALFg");
  this.shape_2.setTransform(39, 35.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));
  this._renderFirstFrame();
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0, 0, 78, 71), null);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1: 144,
   cvr_frame2: 244,
   cvr_frame3: 344,
   cvr_frame4: 444,
   cvr_frame5: 544,
   cvr_frame6: 664,
   cvr_stay: 674
  });
  this.frame_674 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(674).call(this.frame_674));
  this.instance = new lib.logo();
  this.instance.setTransform(630, 0);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(800));
  this.instance_1 = new lib.lgl_main();
  this.instance_1.setTransform(10, 13);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(694).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(75).to({
   alpha: 0
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_2 = new lib.black_plate();
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(660).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 19, cjs.Ease.get(-1)).wait(106));
  this.instance_3 = new lib.txt_t_1_c("synched", 0, false);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({
   _off: false
  }, 0).wait(791));
  this.instance_4 = new lib.s_edition();
  this.instance_4.setTransform(34.6, 60.2, 1, 1, 0, 0, 0, 60.6, 8.2);
  this.instance_4.alpha = 0;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({
   _off: false
  }, 0).to({
   x: 71.6,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(756));
  this.instance_5 = new lib.txt_b_1_c("synched", 0, false);
  this.instance_5.setTransform(0, 90);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(580).to({
   _off: false
  }, 0).wait(220));
  this.instance_6 = new lib.txt_b_5_c("synched", 0, false);
  this.instance_6.setTransform(0, 90);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(479).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 49
  }, 0).to({
   alpha: 0
  }, 30, cjs.Ease.get(-1)).to({
   _off: true
  }, 1).wait(220));
  this.instance_7 = new lib.txt_b_4_c("synched", 0, false);
  this.instance_7.setTransform(0, 90);
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(379).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 49
  }, 0).to({
   alpha: 0
  }, 29, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(321));
  this.instance_8 = new lib.txt_b_3_c("synched", 0, false);
  this.instance_8.setTransform(0, 90);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(279).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 49
  }, 0).to({
   alpha: 0
  }, 29, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(421));
  this.instance_9 = new lib.txt_b_2_c("synched", 0, false);
  this.instance_9.setTransform(0, 90);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(179).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 49
  }, 0).to({
   alpha: 0
  }, 29, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(521));
  this.alx_link2_nogif = new lib.extra_button_1();
  this.alx_link2_nogif.name = "alx_link2_nogif";
  this.alx_link2_nogif.setTransform(438.5, 71.4);
  this.alx_link2_nogif.alpha = 0;
  this.alx_link2_nogif._off = true;
  new cjs.ButtonHelper(this.alx_link2_nogif, 0, 1, 2, false, new lib.extra_button_1(), 3);
  this.cvr_link2_nocatch = new lib.extra_button_1();
  window.cvrTrackButtons[2] = {
   cnvs: this.cvr_link2_nocatch
  };
  this.cvr_link2_nocatch.name = "cvr_link2_nocatch";
  this.cvr_link2_nocatch.setTransform(438.5, 57.4);
  this.cvr_link2_nocatch._off = true;
  new cjs.ButtonHelper(this.cvr_link2_nocatch, 0, 1, 2, false, new lib.extra_button_1(), 3);
  this.timeline.addTween(cjs.Tween.get(this.alx_link2_nogif).wait(50).to({
   _off: false
  }, 0).to({
   _off: true,
   y: 57.4,
   alpha: 1
  }, 20, cjs.Ease.get(1)).wait(730));
  this.timeline.addTween(cjs.Tween.get(this.cvr_link2_nocatch).wait(50).to({
   _off: false
  }, 20, cjs.Ease.get(1)).wait(79).to({
   alpha: 0
  }, 29, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(621));
  this.instance_10 = new lib.offer_plate("synched", 0, false);
  this.instance_10.setTransform(103.2, 43.6, 1.0021, 1, 0, 0, 0, 103, 43.6);
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(30).to({
   _off: false
  }, 0).wait(119).to({
   startPosition: 43
  }, 0).to({
   alpha: 0
  }, 29, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(621));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#404041").s().p("AjTHCIBlk0IBzhQIC/n/IAQAAIizIYIhvBIIh0Ejg");
  this.shape.setTransform(398.125, 45);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#000000").s().p("Au2HCIB0kjIBxhIICyoYIXWAAIAAODg");
  this.shape_1.setTransform(473.7, 45);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(800));
  this.instance_11 = new lib.img_bg5_c();
  this.instance_11.setTransform(250, 45, 1.2, 1.1999);
  this.instance_11.alpha = 0;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(449).to({
   _off: false
  }, 0).to({
   scaleX: 1.1,
   scaleY: 1.0999,
   alpha: 1
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 70, cjs.Ease.get(0.3)).to({
   alpha: 0
  }, 30, cjs.Ease.get(-1)).to({
   _off: true
  }, 1).wait(220));
  this.instance_12 = new lib.img_bg4_c();
  this.instance_12.setTransform(250, 45, 1.2, 1.1999);
  this.instance_12.alpha = 0;
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(349).to({
   _off: false
  }, 0).to({
   scaleX: 1.1,
   scaleY: 1.0999,
   alpha: 1
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 89, cjs.Ease.get(0.3)).to({
   _off: true
  }, 11).wait(321));
  this.instance_13 = new lib.img_bg3_c();
  this.instance_13.setTransform(250, 45, 1.2, 1.1999);
  this.instance_13.alpha = 0;
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(249).to({
   _off: false
  }, 0).to({
   scaleX: 1.1,
   scaleY: 1.0999,
   alpha: 1
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 89, cjs.Ease.get(0.3)).to({
   _off: true
  }, 11).wait(421));
  this.instance_14 = new lib.img_bg2_c();
  this.instance_14.setTransform(250, 45, 1.2, 1.1999);
  this.instance_14.alpha = 0;
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(149).to({
   _off: false
  }, 0).to({
   scaleX: 1.1,
   scaleY: 1.0999,
   alpha: 1
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 90, cjs.Ease.get(0.3)).to({
   _off: true
  }, 10).wait(521));
  this.instance_15 = new lib.img_bg1_c();
  this.instance_15.setTransform(250, 45, 1.2, 1.1999);
  this.timeline.addTween(cjs.Tween.get(this.instance_15).to({
   scaleX: 1.1,
   scaleY: 1.0999
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 139, cjs.Ease.get(0.3)).to({
   _off: true
  }, 10).wait(370).to({
   _off: false,
   scaleX: 1.2,
   scaleY: 1.1999
  }, 0).to({
   scaleX: 1.1,
   scaleY: 1.0999
  }, 30, cjs.Ease.get(0.7)).to({
   scaleX: 1,
   scaleY: 1
  }, 90, cjs.Ease.get(0.3)).wait(131));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-49.9, -8.9, 777.9, 108);
 (lib.toyota_f_728x90 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
  this._renderFirstFrame();
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(314.1, 36.1, 413.9, 62.99999999999999);
 lib.properties = {
  id: 'F3EBD96D0C6A5844AFC3B869827983E9',
  width: 728,
  height: 90,
  fps: 30,
  color: "#666666",
  opacity: 1.00,
  manifest: [{
   src: "txt3_offer_cd.svg",
   id: "txt3_offer_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt3_price_cd.svg",
   id: "txt3_price_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt3_priceOpts_cd.svg",
   id: "txt3_priceOpts_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_t_1_t_1_cd.svg",
   id: "txt_t_1_t_1_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_b_5_b_5_cd.svg",
   id: "txt_b_5_b_5_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_b_4_b_4_cd.svg",
   id: "txt_b_4_b_4_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_b_3_b_3_cd.svg",
   id: "txt_b_3_b_3_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_b_2_b_2_cd.svg",
   id: "txt_b_2_b_2_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "txt_b_1_b_1.svg",
   id: "txt_b_1_b_1",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "lgl_main_legal1_cd.svg",
   id: "lgl_main_legal1_cd",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "extra_button_1_alx_txt_button.svg",
   id: "extra_button_1_alx_txt_button",
   type: cjs.LoadQueue.IMAGE
  }, {
   src: "img_bg5_bg5_cd.jpg",
   id: "img_bg5_bg5_cd"
  }, {
   src: "img_bg4_bg4_cd.jpg",
   id: "img_bg4_bg4_cd"
  }, {
   src: "img_bg3_bg3_cd.jpg",
   id: "img_bg3_bg3_cd"
  }, {
   src: "img_bg2_bg2_cd.jpg",
   id: "img_bg2_bg2_cd"
  }, {
   src: "img_bg1_bg1_cd.jpg",
   id: "img_bg1_bg1_cd"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.StageGL();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['F3EBD96D0C6A5844AFC3B869827983E9'] = {
  getStage: function() {
   return exportRoot.stage;
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;